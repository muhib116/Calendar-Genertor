import { useContext, memo } from 'react'
import classes from './index.module.css'
import calendarContext from '../../../context/calendarContext'
import CoverPage from '../CalendarPreview/CoverPage'
import BackPage from '../CalendarPreview/BackPage'
import whiteCalendar from '../../../assets/white-calendar.png'
import blackCalendar from '../../../assets/black-calendar.png'
import CalendarPreview from '@/Components/calendar/CalendarPreview/index'
import { listOfMonth } from '../../../calendarData'


const PreviewChanger = () => {
  const { calendarImages, selectedYear, selectedMonth, calendarTheme, setSelectedMonth, language } = useContext(calendarContext)
  const handleMonth = (index) => {
    setSelectedMonth(index)
  }

  return (
    <div className={[classes.wrapper, 'h-full flex gap-2 text-xs overflow-x-auto w-full justify-center'].join(' ')}>
      <div 
        onClick={ () => handleMonth(-1) } 
        className={ ['cursor-pointer p-1 text-center grid items-end border rounded hover:shadow active:scale-95',
          (selectedMonth === -1) && 'shadow scale-95 border-red-500'
        ].join(' ') }
      >
        <div className='w-full h-[104px] overflow-hidden'>
          <CoverPage 
            img={ calendarImages.length>0 ? calendarImages.find(item=>item.name == 'cover').path : '' }
            style={{ 
              transform: 'scale(0.14)',
              transformOrigin: 'left top',
              height: '700px'
            }}
          />
        </div>
        Cover
      </div>
      {
        listOfMonth.map((item, index) => (
          <div 
            onClick={ () => handleMonth(index) } 
            key={ 'previewChangerKey-'+index } 
            className={ [
              'cursor-pointer p-1 text-center grid items-end border hover:shadow-md active:scale-95 rounded',
              (selectedMonth === index) && 'shadow scale-95 border-red-500'
            ].join(' ') } 
          >
            <div className='w-full h-[104px] overflow-hidden'>
              <CalendarPreview 
                  // img={ calendarImages.length>0 ? calendarImages.find(item=>item.name == 'cover').path : '' }
                  img={ calendarImages.length>0 ? calendarImages.find(item=>item.name == listOfMonth[index]['english']).path : '' }
                  selectedMonth={ index } 
                  selectedYear={ selectedYear } 
                  style={{ 
                    transform: 'scale(0.14)',
                    transformOrigin: 'left top',
                    height: '700px'
                  }}
              />
            </div>

            { item[language].slice(0, 3) } - { selectedYear }
          </div>
        ))
      }
      <div 
        onClick={ () => handleMonth(12) } 
        className={ ['cursor-pointer p-1 text-center grid items-end border rounded hover:shadow active:scale-95',
          (selectedMonth === 12) && 'shadow scale-95 border-red-500'
        ].join(' ') }
      >
        <div className='w-full h-[104px] overflow-hidden'>
          <BackPage 
            img={ calendarImages.length>0 ? calendarImages.find(item=>item.name == 'back').path : '' }
            style={{ 
              transform: 'scale(0.14)',
              transformOrigin: 'left top',
              height: '700px'
            }}
          />
        </div>
        Back
      </div>
    </div>
  )
}


export default memo(PreviewChanger)