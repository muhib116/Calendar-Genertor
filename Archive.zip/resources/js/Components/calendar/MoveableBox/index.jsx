import Draggable from 'react-draggable';

export default function MoveableBox()
{
  return (
    <div className='absolute top-0 z-20 p-5 cursor-move hidden'>MoveableBox</div>
  )
}
